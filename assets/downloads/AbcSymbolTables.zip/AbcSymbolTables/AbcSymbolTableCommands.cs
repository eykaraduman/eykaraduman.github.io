// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Colors;

[assembly: CommandClass(typeof(AbcSymbolTables.AbcSymbolTableCommands))]

namespace AbcSymbolTables
{
    /// <summary>
    /// Summary description for CNETCommands.
    /// </summary>
    public class AbcSymbolTableCommands
    {
        public AbcSymbolTableCommands()
        {

        }

        #region Komutlar

        [CommandMethod("KtmEk")]
        static public void KatmanEkle()
        {
            KatmanOlustur(Application.DocumentManager.MdiActiveDocument.Database,
                "AbcProgramlama", "HIDDEN", 1);
        }

        [CommandMethod("TxtStyEk")]
        static public void MetinBicemEkle()
        {
            MetinBicemOlustur(Application.DocumentManager.MdiActiveDocument.Database,
                "Txt.shx", "Metin", 0.00, 1.00);
        }

        [CommandMethod("NODListe")]
        static public void NODKayitlar()
        {
            NODKayitListele();
        }

        [CommandMethod("BlkTblListe")]
        static public void BlokTabloKayitlar()
        {
            BlokTabloKayitListele();
        }

        [CommandMethod("BlkTblEkle")]
        static public void BlokTabloEkle()
        {
            YeniBlokTabloOlustur("CizgiBlok");
        }

        [CommandMethod("MsEkle")]
        static public void MsNesneEkle()
        {
            Line cizgi = new Line(new Point3d(0.0, 0.0, 0.0),
                new Point3d(0.0, 1.0, 0.0));
            ModelUzayinaNesleEkle(cizgi);
        }

        [CommandMethod("PsEkle")]
        static public void PsNesneEkle()
        {
            Line cizgi = new Line(new Point3d(0.0, 0.0, 0.0),
                new Point3d(0.0, 1.0, 0.0));
            KagitUzayinaNesleEkle(cizgi);
        }

        [CommandMethod("CsEkle")]
        static public void CsNesneEkle()
        {
            Line cizgi = new Line(new Point3d(0.0, 0.0, 0.0),
                new Point3d(0.0, 1.0, 0.0));
            AktifUzayaNesneEkle(cizgi);
        }

        [CommandMethod("SmbTblDia")]
        public static void SembolDialog()
        {
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(new SymbolTableForm());
        }

        [CommandMethod("DictDia")]
        public static void DictionaryDialog()
        {
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModalDialog(new UygulamaSozlukForm());
        }

        
        #endregion

        #region Yard�mc� fonksiyonlar

        public static ObjectId SembolTabloNesneKimlikAl(Database db, Type SinifTip)
        {
            if (SinifTip == typeof(BlockTableRecord))
                return db.BlockTableId;
            if (SinifTip == typeof(DimStyleTableRecord))
                return db.DimStyleTableId;
            if (SinifTip == typeof(LayerTableRecord))
                return db.LayerTableId;
            if (SinifTip == typeof(LinetypeTableRecord))
                return db.LinetypeTableId;
            if (SinifTip == typeof(TextStyleTableRecord))
                return db.TextStyleTableId;
            if (SinifTip == typeof(RegAppTableRecord))
                return db.RegAppTableId;
            if (SinifTip == typeof(UcsTableRecord))
                return db.UcsTableId;
            if (SinifTip == typeof(ViewTableRecord))
                return db.ViewTableId;
            if (SinifTip == typeof(ViewportTableRecord))
                return db.ViewportTableId;
            return ObjectId.Null;
        }

        public static ObjectId SembolTabloKayitNesneKimlikAl(Database db, Type SinifTip,
            string SymAd)
        {
            ObjectId symbolTableId = SembolTabloNesneKimlikAl(db, SinifTip);
            ObjectId recId = ObjectId.Null;
            using (Transaction transaction = db.TransactionManager.StartTransaction())
            {
                SymbolTable table = (SymbolTable)transaction.GetObject(symbolTableId,
                    OpenMode.ForRead);
                if (table.Has(SymAd))
                {
                    recId = table[SymAd];
                }
            }
            return recId;
        }

        public static bool SembolTabloKaydiMevcutMu(Database db, Type SinifTip,
            string SymAd)
        {
            bool mevcut = false;
            ObjectId symbolTableId = SembolTabloNesneKimlikAl(db, SinifTip);
            using (Transaction transaction = db.TransactionManager.StartTransaction())
            {
                mevcut = ((SymbolTable)transaction.GetObject(symbolTableId,
                    OpenMode.ForRead)).Has(SymAd);
            }
            return mevcut;
        }

        public static ObjectId CizgiTipiKimlikAlYadaYukle(string CizgiTipDosya,
            string CizgiTipAd)
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;

            ObjectId id = SembolTabloKayitNesneKimlikAl(db, typeof(LinetypeTableRecord),
                CizgiTipAd);
            if (!id.IsNull)
                return id;
            try
            {
                db.LoadLineTypeFile(CizgiTipAd, CizgiTipDosya);
                id = SembolTabloKayitNesneKimlikAl(db, typeof(LinetypeTableRecord), CizgiTipAd);
                if (!id.IsNull)
                    return id;
                else
                    return db.ContinuousLinetype;
            }
            catch
            {
                return db.ContinuousLinetype;
            }

        } 

        #endregion

        #region Komut fonksiyonlar�

        public static ObjectId KatmanOlustur(Database db, string KatmanAdi,
            string KatmanCizgiTipiAdi, short KatmanRengi)
        {
            ObjectId id = ObjectId.Null;
            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                // Eklemek istedi�imiz katman�n�n varl���n� sorgulamak i�in
                // katman tablosunu okuma ama�l� a�al�m.
                LayerTable tbl = (LayerTable)trans.GetObject(db.LayerTableId,
                    OpenMode.ForRead);
                // Eklemek iste�imiz katman mevcutsa  
                // kay�t kimli�ini fonksiyon geri d�n�� de�erine atayal�m.
                if (tbl.Has(KatmanAdi))
                    id = tbl[KatmanAdi];
                else
                {
                    // Eklemek istedi�imiz katman�n varolmad���na art�k eminiz.
                    // Yeni katman tablo kayd�n� olu�tural�m.
                    LayerTableRecord rec = new LayerTableRecord();
                    rec.Name = KatmanAdi;
                    rec.Color = Color.FromColorIndex(ColorMethod.ByAci, KatmanRengi);
                    ObjectId lineId = CizgiTipiKimlikAlYadaYukle("acadiso.lin",
                        KatmanCizgiTipiAdi);
                    if (lineId != ObjectId.Null) rec.LinetypeObjectId = lineId;
                    // Daha �nce okuma ama�l� a�t���m�z katman tablosunu
                    // kayd� eklemek i�in yazma ama�l� a�al�m.
                    tbl.UpgradeOpen();
                    //Katman tablosuna kayd� ekleyelim.
                    id = tbl.Add(rec);
                    // ��lem y���n�n�n kayd� sahiplenmesini sa�layal�m.
                    trans.AddNewlyCreatedDBObject(rec, true);
                    // ��lem y���n�n� onaylayal�m.
                    trans.Commit();
                }
            }
            return id;
        }

        public static ObjectId MetinBicemOlustur(Database db, string MetinDosyaAdi,
            string MetinStilAd, double MetinYks, double GenislikFaktor)
        {
            ObjectId id = ObjectId.Null;
            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                // Eklemek istedi�imiz metin bi�eminin varl���n� 
                // sorgulamak i�in metin bi�em tablosunu okuma ama�l� a�al�m.
                TextStyleTable tbl = (TextStyleTable)trans.GetObject(db.TextStyleTableId,
                    OpenMode.ForRead);
                // Eklemek iste�imiz metin bi�emi mevcutsa  
                // kay�t kimli�ini fonksiyon geri d�n�� de�erine atayal�m.
                if (tbl.Has(MetinStilAd))
                    id = tbl[MetinStilAd];
                else
                {
                    // Eklemek istedi�imiz metin bi�eminin varolmad���na art�k eminiz.
                    // Yeni metin bi�emi tablo kayd�n� olu�tural�m.
                    TextStyleTableRecord rec = new TextStyleTableRecord();
                    rec.Name = MetinStilAd;
                    rec.FileName = MetinDosyaAdi;
                    rec.BigFontFileName = "";
                    rec.ObliquingAngle = 0.0;
                    rec.TextSize = MetinYks;
                    rec.XScale = GenislikFaktor;
                    // Daha �nce okuma ama�l� a�t���m�z metin bi�em tablosunu
                    // kayd� eklemek i�in yazma ama�l� a�al�m.
                    tbl.UpgradeOpen();
                    //Metin bi�em tablosuna kayd� ekleyelim.
                    id = tbl.Add(rec);
                    // ��lem y���n�n�n kayd� sahiplenmesini sa�layal�m.
                    trans.AddNewlyCreatedDBObject(rec, true);
                    // ��lem y���n�n� onaylayal�m.
                    trans.Commit();
                }
            }
            return id;
        }

        public static void NODKayitListele()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;
            ed.WriteMessage("\nAdland�r�lm�� Nesne S�zl��� (NOD) Kay�tlar�:");
            ed.WriteMessage("\n--------------------------------------------");
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                // Veritaban� s�zl���n�n (NOD'un) okuma ama�l� a��lmas�
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForRead);
                // S�zl�k i�erisinde dola�mak i�in
                // veritaban� s�zl�k numaraland�r�c�s�n�n eldesi
                DbDictionaryEnumerator eNOD = NOD.GetEnumerator();
                while (eNOD.MoveNext())
                {
                    // S�zl�k kay�t anahtarlar�n�n AutoCAD 
                    // komut sat�r�na yazd�r�lmas�
                    ed.WriteMessage("\n{0}", eNOD.Current.Key);
                }
                // Numaraland�r�c�n�n sonland�r�lmas�
                eNOD.Dispose();
            }
        }

        public static void BlokTabloKayitListele()
        {
            Document doc = Application.DocumentManager.MdiActiveDocument;
            Database db = doc.Database;
            Editor ed = doc.Editor;
            string BlockTableKayitListe = "Blok Tablosu Kay�t Listesi :";
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                // Block tablosunun okuma ama�l� a��lmas�
                BlockTable blockTable =
                    (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                // Blok tablosu i�erisinde dola�mak i�in
                // sembol tablo numaraland�r�c�s�n�n eldesi
                SymbolTableEnumerator eBlockTable = blockTable.GetEnumerator();
                while (eBlockTable.MoveNext())
                {
                    // Sembol tablo kayd�n�n eldesi
                    SymbolTableRecord blockTableRec =
                        (SymbolTableRecord)tr.GetObject(eBlockTable.Current, OpenMode.ForRead);
                    BlockTableKayitListe += "\n" + blockTableRec.Name;
                }
                // Numaraland�r�c�n�n sonland�r�lmas�
                eBlockTable.Dispose();
                Application.ShowAlertDialog(BlockTableKayitListe);
            }
        }

        public static void YeniBlokTabloOlustur(string blkName)
        {
            Database db = Application.DocumentManager.MdiActiveDocument.Database;
            // ��lem y���n�n�n ba�lat�lmas�
            using (Transaction transaction = db.TransactionManager.StartTransaction())
            {
                // Blok tablosunun yazma ama�l� eldesi
                BlockTable blkTable =
                    (BlockTable)transaction.GetObject(db.BlockTableId, OpenMode.ForWrite);
                // Blok tablosu eklemek istedi�imiz blok ad�n� i�eriyor mu?
                // (Var olan bir blo�un ayn� adla tekrar olu�urulmaya �al���lmas� bir
                //  hataya neden olaca��ndan kontrol edilmelidir.)
                if (!blkTable.Has(blkName))
                {
                    // Blo�a eklenecek �izginin olu�turulmas�
                    Line cizgi =
                        new Line(new Point3d(0.0, 0.0, 0.0), new Point3d(0.0, 1.0, 0.0));
                    // Blok tablo kayd� �ren�inin olu�turulmas�
                    BlockTableRecord blkRec = new BlockTableRecord();
                    // Blok isminin kayda atanmas�
                    blkRec.Name = blkName;
                    // Blok kayd�na daha �nce tan�mlanan �izgi nesnesini eklenmesi
                    blkRec.AppendEntity(cizgi);
                    // Blok kayd�n�n blok tablosuna eklenmesi
                    blkTable.Add(blkRec);
                    // Blok kayd�n�n i�lem y���n� taraf�ndan sahiplenilmesi
                    transaction.AddNewlyCreatedDBObject(blkRec, true);
                    // ��lem y���n�n�n onaylanmas�
                    transaction.Commit();
                }
            }
        }

        public static void ModelUzayinaNesleEkle(Entity ent)
        {
            // �izim veritaban�n�n eldesi
            Database db = Application.DocumentManager.MdiActiveDocument.Database;
            // ��lem y���n� y�neticisinin eldesi
            Autodesk.AutoCAD.DatabaseServices.TransactionManager transactionManager =
                db.TransactionManager;
            // ��lem y���n�n�n ba�lat�lmas�
            using (Transaction transaction = transactionManager.StartTransaction())
            {
                // Blok tablosunun okuma ama�l� a��lmas�
                BlockTable blkTable = (BlockTable)transactionManager.GetObject(db.BlockTableId,
                    OpenMode.ForRead, false);
                // Model uzay� kayd�n�n yazma ama�l� a��lmas�
                BlockTableRecord blkTableRec =
                    (BlockTableRecord)transactionManager.GetObject(blkTable[BlockTableRecord.ModelSpace],
                    OpenMode.ForWrite, false);
                // Nesnenin model uzay�na eklenmesi
                blkTableRec.AppendEntity(ent);
                // ��lem y���n�nca nesnenin sahiplenilmesi
                transactionManager.AddNewlyCreatedDBObject(ent, true);
                // ��lem y���n�n�n onaylanmas�
                transaction.Commit();
            }
        }

        public static void KagitUzayinaNesleEkle(Entity ent)
        {
            // �izim veritaban�n�n eldesi
            Database db = Application.DocumentManager.MdiActiveDocument.Database;
            // ��lem y���n� y�neticisinin eldesi
            Autodesk.AutoCAD.DatabaseServices.TransactionManager transactionManager =
                db.TransactionManager;
            // ��lem y���n�n�n ba�lat�lmas�
            using (Transaction transaction = transactionManager.StartTransaction())
            {
                // Blok tablosunun okuma ama�l� a��lmas�
                BlockTable blkTable = (BlockTable)transactionManager.GetObject(db.BlockTableId,
                    OpenMode.ForRead, false);
                // Ka��t uzay� kayd�n�n yazma ama�l� a��lmas�
                BlockTableRecord blkTableRec =
                    (BlockTableRecord)transactionManager.GetObject(blkTable[BlockTableRecord.PaperSpace],
                    OpenMode.ForWrite, false);
                // Nesnenin model uzay�na eklenmesi
                blkTableRec.AppendEntity(ent);
                // ��lem y���n�nca nesnenin sahiplenilmesi
                transactionManager.AddNewlyCreatedDBObject(ent, true);
                // ��lem y���n�n�n onaylanmas�
                transaction.Commit();
            }
        }

        public static void AktifUzayaNesneEkle(Entity ent)
        {
            // �izim veritaban�n�n eldesi
            Database db = Application.DocumentManager.MdiActiveDocument.Database;
            // ��lem y���n� y�neticisinin eldesi
            Autodesk.AutoCAD.DatabaseServices.TransactionManager transactionManager = db.TransactionManager;
            // ��lem y���n�n�n ba�lat�lmas�
            using (Transaction transaction = transactionManager.StartTransaction())
            {
                // Ka��t uzay� kayd�n�n yazma ama�l� a��lmas�
                BlockTableRecord blkTableRec =
                    (BlockTableRecord)transactionManager.GetObject(db.CurrentSpaceId, OpenMode.ForWrite, false);
                // Nesnenin aktif uzaya eklenmesi
                blkTableRec.AppendEntity(ent);
                // ��lem y���n�nca nesnenin sahiplenilmesi
                transactionManager.AddNewlyCreatedDBObject(ent, true);
                // ��lem y���n�n�n onaylanmas�
                transaction.Commit();
            }
        }

        #endregion

    }
}