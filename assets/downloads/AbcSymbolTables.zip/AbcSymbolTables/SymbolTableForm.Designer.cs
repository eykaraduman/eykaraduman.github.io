namespace AbcSymbolTables
{
    partial class SymbolTableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SembolTabloList = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SembolKayitList = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.katmanAdi = new System.Windows.Forms.TextBox();
            this.renkSec = new System.Windows.Forms.Button();
            this.katmanRenk = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.katmanCizgi = new System.Windows.Forms.TextBox();
            this.cizgiSec = new System.Windows.Forms.Button();
            this.katmanOlustur = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // SembolTabloList
            // 
            this.SembolTabloList.FormattingEnabled = true;
            this.SembolTabloList.Items.AddRange(new object[] {
            "BlockTable",
            "DimStyleTable",
            "LayerTable",
            "LinetypeTable",
            "RegAppTable",
            "TextStyleTable",
            "UcsTable",
            "ViewportTable",
            "ViewTable",
            "NOD",
            "ColorDictionary",
            "GroupDictionary",
            "LayoutDictionary",
            "MaterialDictionary",
            "MLeaderStyleDictionary",
            "MLStyleDictionary",
            "PlotSettingsDictionary",
            "PlotStyleNameDictionary",
            "TableStyleDictionary",
            "VisualStyleDictionary"});
            this.SembolTabloList.Location = new System.Drawing.Point(12, 37);
            this.SembolTabloList.Name = "SembolTabloList";
            this.SembolTabloList.Size = new System.Drawing.Size(160, 264);
            this.SembolTabloList.TabIndex = 0;
            this.SembolTabloList.SelectedIndexChanged += new System.EventHandler(this.SembolTabloList_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Sembol Tablolar�";
            // 
            // SembolKayitList
            // 
            this.SembolKayitList.FormattingEnabled = true;
            this.SembolKayitList.Location = new System.Drawing.Point(178, 37);
            this.SembolKayitList.Name = "SembolKayitList";
            this.SembolKayitList.Size = new System.Drawing.Size(237, 264);
            this.SembolKayitList.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(175, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Kay�tlar";
            // 
            // button1
            // 
            this.button1.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button1.Location = new System.Drawing.Point(340, 390);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "��k��";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Ad�";
            // 
            // katmanAdi
            // 
            this.katmanAdi.Location = new System.Drawing.Point(6, 38);
            this.katmanAdi.Name = "katmanAdi";
            this.katmanAdi.Size = new System.Drawing.Size(100, 20);
            this.katmanAdi.TabIndex = 6;
            // 
            // renkSec
            // 
            this.renkSec.Location = new System.Drawing.Point(149, 36);
            this.renkSec.Name = "renkSec";
            this.renkSec.Size = new System.Drawing.Size(25, 23);
            this.renkSec.TabIndex = 7;
            this.renkSec.Text = "...";
            this.renkSec.UseVisualStyleBackColor = true;
            this.renkSec.Click += new System.EventHandler(this.renkSec_Click);
            // 
            // katmanRenk
            // 
            this.katmanRenk.Enabled = false;
            this.katmanRenk.Location = new System.Drawing.Point(121, 38);
            this.katmanRenk.Name = "katmanRenk";
            this.katmanRenk.Size = new System.Drawing.Size(22, 20);
            this.katmanRenk.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Rengi";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.katmanOlustur);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.katmanCizgi);
            this.groupBox1.Controls.Add(this.cizgiSec);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.katmanRenk);
            this.groupBox1.Controls.Add(this.renkSec);
            this.groupBox1.Controls.Add(this.katmanAdi);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(13, 311);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(401, 73);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Katman";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(186, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "�izgi Tipi";
            // 
            // katmanCizgi
            // 
            this.katmanCizgi.Location = new System.Drawing.Point(189, 39);
            this.katmanCizgi.Name = "katmanCizgi";
            this.katmanCizgi.ReadOnly = true;
            this.katmanCizgi.Size = new System.Drawing.Size(101, 20);
            this.katmanCizgi.TabIndex = 11;
            // 
            // cizgiSec
            // 
            this.cizgiSec.Location = new System.Drawing.Point(296, 36);
            this.cizgiSec.Name = "cizgiSec";
            this.cizgiSec.Size = new System.Drawing.Size(25, 23);
            this.cizgiSec.TabIndex = 10;
            this.cizgiSec.Text = "...";
            this.cizgiSec.UseVisualStyleBackColor = true;
            this.cizgiSec.Click += new System.EventHandler(this.cizgiSec_Click);
            // 
            // katmanOlustur
            // 
            this.katmanOlustur.Location = new System.Drawing.Point(327, 36);
            this.katmanOlustur.Name = "katmanOlustur";
            this.katmanOlustur.Size = new System.Drawing.Size(68, 23);
            this.katmanOlustur.TabIndex = 13;
            this.katmanOlustur.Text = "Olu�tur";
            this.katmanOlustur.UseVisualStyleBackColor = true;
            this.katmanOlustur.Click += new System.EventHandler(this.katmanOlustur_Click);
            // 
            // SymbolTableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 422);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.SembolKayitList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SembolTabloList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SymbolTableForm";
            this.ShowInTaskbar = false;
            this.Text = "AutoCAD.Net API ile Sembol Tablolar�";
            this.Load += new System.EventHandler(this.SymbolTableForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox SembolTabloList;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox SembolKayitList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox katmanAdi;
        private System.Windows.Forms.Button renkSec;
        private System.Windows.Forms.TextBox katmanRenk;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button katmanOlustur;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox katmanCizgi;
        private System.Windows.Forms.Button cizgiSec;
    }
}