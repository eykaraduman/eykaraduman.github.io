using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Windows;

namespace AbcSymbolTables
{
    public enum SembolTablolar { BlockTable, DimStyleTable, LayerTable, LinetypeTable, RegAppTable,
                                 TextStyleTable, UcsTable, ViewportTable, ViewTable, NOD, ColorDictionary, GroupDictionary,
                                 LayoutDictionary, MaterialDictionary, MLeaderStyleDictionary,MLStyleDictionary,
                                 PlotSettingsDictionary, PlotStyleNameDictionary, TableStyleDictionary, VisualStyleDictionary, Null }

    public partial class SymbolTableForm : Form
    {
        private ObjectId SymTblId = ObjectId.Null;
        Autodesk.AutoCAD.DatabaseServices.Database db = null;
        Document doc = null;
        SembolTablolar SembolTablo = SembolTablolar.Null;
        Autodesk.AutoCAD.Colors.Color layCol = 
            Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByLayer, 0);
        ObjectId ltypeId = ObjectId.Null;

        public SymbolTableForm()
        {
            InitializeComponent();
        }

        private void SembolTabloList_SelectedIndexChanged(object sender, EventArgs e)
        {
            SembolKayitList.Items.Clear();
            SembolTablo = (SembolTablolar)SembolTabloList.SelectedIndex;
            switch (SembolTablo)
            {
                case SembolTablolar.BlockTable:
                    BlokTabloListe();
                    break;
                case SembolTablolar.DimStyleTable:
                    SembolTabloListe(db.DimStyleTableId);
                    break;
                case SembolTablolar.LayerTable:
                    SembolTabloListe(db.LayerTableId);
                    break;
                case SembolTablolar.LinetypeTable:
                    SembolTabloListe(db.LinetypeTableId);
                    break;
                case SembolTablolar.RegAppTable:
                    SembolTabloListe(db.RegAppTableId);
                    break;
                case SembolTablolar.TextStyleTable:
                    SembolTabloListe(db.TextStyleTableId);
                    break;
                case SembolTablolar.UcsTable:
                    SembolTabloListe(db.UcsTableId);
                    break;
                case SembolTablolar.ViewportTable:
                    SembolTabloListe(db.ViewportTableId);
                    break;
                case SembolTablolar.ViewTable:
                    SembolTabloListe(db.ViewTableId);
                    break;
                case SembolTablolar.NOD:
                    NODListe();
                    break;
                case SembolTablolar.ColorDictionary:
                    DictionaryListe(db.ColorDictionaryId);
                    break;
                case SembolTablolar.GroupDictionary:
                    DictionaryListe(db.GroupDictionaryId);
                    break;
                case SembolTablolar.LayoutDictionary:
                    DictionaryListe(db.LayoutDictionaryId);
                    break;
                case SembolTablolar.MaterialDictionary:
                    DictionaryListe(db.MaterialDictionaryId);
                    break;
                case SembolTablolar.MLeaderStyleDictionary:
                    DictionaryListe(db.MLeaderStyleDictionaryId);
                    break;
                case SembolTablolar.MLStyleDictionary:
                    DictionaryListe(db.MLStyleDictionaryId);
                    break;
                case SembolTablolar.PlotSettingsDictionary:
                    DictionaryListe(db.PlotSettingsDictionaryId);
                    break;
                case SembolTablolar.PlotStyleNameDictionary:
                    DictionaryListe(db.PlotStyleNameDictionaryId);
                    break;
                case SembolTablolar.TableStyleDictionary:
                    DictionaryListe(db.TableStyleDictionaryId);
                    break;
                case SembolTablolar.VisualStyleDictionary:
                    DictionaryListe(db.VisualStyleDictionaryId);
                    break;
                case SembolTablolar.Null:
                    break;
                default:
                    break;
            }
        }

        private void SymbolTableForm_Load(object sender, EventArgs e)
        {
            doc = Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument;
            db = doc.Database;
        }

        private void NODListe()
        {   
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForRead);
                DbDictionaryEnumerator eNOD = NOD.GetEnumerator();
                while (eNOD.MoveNext())
                {
                    SembolKayitList.Items.Add(eNOD.Current.Key);
                }
                eNOD.Dispose();
            }
        }

        private void BlokTabloListe()
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                BlockTable blockTable =
                    (BlockTable)tr.GetObject(db.BlockTableId, OpenMode.ForRead);
                SymbolTableEnumerator eBlockTable = blockTable.GetEnumerator();
                while (eBlockTable.MoveNext())
                {
                    SymbolTableRecord blockTableRec =
                        (SymbolTableRecord)tr.GetObject(eBlockTable.Current, OpenMode.ForRead);
                    SembolKayitList.Items.Add(blockTableRec.Name);
                }
                eBlockTable.Dispose();
            }
        }

        private void SembolTabloListe(ObjectId tblId)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                SymbolTable symTable =
                    (SymbolTable)tr.GetObject(tblId, OpenMode.ForRead);
                SymbolTableEnumerator eSymbolTable = symTable.GetEnumerator();
                while (eSymbolTable.MoveNext())
                {
                    SymbolTableRecord symTableRec =
                        (SymbolTableRecord)tr.GetObject(eSymbolTable.Current, OpenMode.ForRead);
                    SembolKayitList.Items.Add(symTableRec.Name);
                }
                eSymbolTable.Dispose();
            }
        }

        private void DictionaryListe(ObjectId dictId)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary tblStyleDict = (DBDictionary)tr.GetObject(dictId, OpenMode.ForRead);
                DbDictionaryEnumerator eNOD = tblStyleDict.GetEnumerator();
                while (eNOD.MoveNext())
                {
                    SembolKayitList.Items.Add(eNOD.Current.Key);
                }
                eNOD.Dispose();
            }
        }

        private void renkSec_Click(object sender, EventArgs e)
        {
            Autodesk.AutoCAD.Windows.ColorDialog clrDlg = new Autodesk.AutoCAD.Windows.ColorDialog();
            DialogResult dlgRes = clrDlg.ShowDialog();
            if (dlgRes == DialogResult.OK)
            {                
                layCol = clrDlg.Color;
            }
            else
            {
                layCol =
                    Autodesk.AutoCAD.Colors.Color.FromColorIndex(Autodesk.AutoCAD.Colors.ColorMethod.ByLayer, 0);
            }

            katmanRenk.BackColor = layCol.ColorValue;
        }

        private void cizgiSec_Click(object sender, EventArgs e)
        {
            Autodesk.AutoCAD.Windows.LinetypeDialog ltypeDlg = new LinetypeDialog();
            DialogResult dlgRes = ltypeDlg.ShowDialog();
            if (dlgRes == DialogResult.OK)
            {
                ltypeId = ltypeDlg.Linetype;
            }
            else
            {
                ltypeId = db.ContinuousLinetype;
            }
            katmanCizgi.Text = SymbolRecordIdToName(ltypeId);
        }

        private void katmanOlustur_Click(object sender, EventArgs e)
        {
            if (katmanAdi.Text != "")
            {
                string layerName = SymbolUtilityServices.RepairSymbolName(katmanAdi.Text, true);
                KatmanOlustur(layerName, ltypeId, layCol);
                Autodesk.AutoCAD.ApplicationServices.Application.ShowAlertDialog("\"" + layerName + "\" katman� ba�ar�yla olu�turuldu.");
            }
        }

        private void KatmanOlustur(string LayerName, ObjectId LineTypeId, Autodesk.AutoCAD.Colors.Color LayerColor)
        {
            using (Transaction trans = db.TransactionManager.StartTransaction())
            {
                LayerTable tbl = (LayerTable)trans.GetObject(db.LayerTableId,
                    OpenMode.ForRead);
                if (!tbl.Has(LayerName))
                {
                    LayerTableRecord rec = new LayerTableRecord();
                    rec.Name = LayerName;
                    rec.Color = LayerColor;
                    rec.LinetypeObjectId = LineTypeId;
                    tbl.UpgradeOpen();
                    tbl.Add(rec);
                    trans.AddNewlyCreatedDBObject(rec, true);
                    trans.Commit();
                }
            }
        }

        private string SymbolRecordIdToName(ObjectId symId)
        {
            string str = null;
            using (Transaction transaction = db.TransactionManager.StartTransaction())
            {
                SymbolTableRecord record = (SymbolTableRecord)transaction.GetObject(symId, OpenMode.ForWrite);
                if (record != null)
                {
                    str = record.Name;
                }
            }
            return str;
        }

       
    }
}