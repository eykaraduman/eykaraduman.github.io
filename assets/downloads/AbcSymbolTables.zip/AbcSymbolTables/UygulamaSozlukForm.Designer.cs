namespace AbcSymbolTables
{
    partial class UygulamaSozlukForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dictName = new System.Windows.Forms.TextBox();
            this.btNodList = new System.Windows.Forms.Button();
            this.btnDictExist = new System.Windows.Forms.Button();
            this.btnDictCreate = new System.Windows.Forms.Button();
            this.btnDictRemove = new System.Windows.Forms.Button();
            this.recKeyName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.recValue = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRecList = new System.Windows.Forms.Button();
            this.btnRecAdd = new System.Windows.Forms.Button();
            this.btnRecRemove = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "S�zl�k Ad�";
            // 
            // dictName
            // 
            this.dictName.Location = new System.Drawing.Point(90, 6);
            this.dictName.Name = "dictName";
            this.dictName.Size = new System.Drawing.Size(164, 20);
            this.dictName.TabIndex = 1;
            // 
            // btNodList
            // 
            this.btNodList.Location = new System.Drawing.Point(90, 32);
            this.btNodList.Name = "btNodList";
            this.btNodList.Size = new System.Drawing.Size(79, 23);
            this.btNodList.TabIndex = 2;
            this.btNodList.Text = "NOD Liste";
            this.btNodList.UseVisualStyleBackColor = true;
            this.btNodList.Click += new System.EventHandler(this.btNodList_Click);
            // 
            // btnDictExist
            // 
            this.btnDictExist.Location = new System.Drawing.Point(175, 32);
            this.btnDictExist.Name = "btnDictExist";
            this.btnDictExist.Size = new System.Drawing.Size(79, 23);
            this.btnDictExist.TabIndex = 3;
            this.btnDictExist.Text = "Mevcut mu?";
            this.btnDictExist.UseVisualStyleBackColor = true;
            this.btnDictExist.Click += new System.EventHandler(this.btnDictExist_Click);
            // 
            // btnDictCreate
            // 
            this.btnDictCreate.Location = new System.Drawing.Point(90, 61);
            this.btnDictCreate.Name = "btnDictCreate";
            this.btnDictCreate.Size = new System.Drawing.Size(79, 23);
            this.btnDictCreate.TabIndex = 4;
            this.btnDictCreate.Text = "Olu�tur";
            this.btnDictCreate.UseVisualStyleBackColor = true;
            this.btnDictCreate.Click += new System.EventHandler(this.btnDictCreate_Click);
            // 
            // btnDictRemove
            // 
            this.btnDictRemove.Location = new System.Drawing.Point(175, 61);
            this.btnDictRemove.Name = "btnDictRemove";
            this.btnDictRemove.Size = new System.Drawing.Size(79, 23);
            this.btnDictRemove.TabIndex = 5;
            this.btnDictRemove.Text = "Sil";
            this.btnDictRemove.UseVisualStyleBackColor = true;
            this.btnDictRemove.Click += new System.EventHandler(this.btnDictRemove_Click);
            // 
            // recKeyName
            // 
            this.recKeyName.Location = new System.Drawing.Point(90, 103);
            this.recKeyName.Name = "recKeyName";
            this.recKeyName.Size = new System.Drawing.Size(164, 20);
            this.recKeyName.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Kay�t Anahtar�";
            // 
            // recValue
            // 
            this.recValue.Location = new System.Drawing.Point(90, 129);
            this.recValue.Name = "recValue";
            this.recValue.Size = new System.Drawing.Size(164, 20);
            this.recValue.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Kay�t De�eri";
            // 
            // btnRecList
            // 
            this.btnRecList.Location = new System.Drawing.Point(90, 155);
            this.btnRecList.Name = "btnRecList";
            this.btnRecList.Size = new System.Drawing.Size(79, 23);
            this.btnRecList.TabIndex = 12;
            this.btnRecList.Text = "Kay�t Liste";
            this.btnRecList.UseVisualStyleBackColor = true;
            this.btnRecList.Click += new System.EventHandler(this.btnRecList_Click);
            // 
            // btnRecAdd
            // 
            this.btnRecAdd.Location = new System.Drawing.Point(175, 155);
            this.btnRecAdd.Name = "btnRecAdd";
            this.btnRecAdd.Size = new System.Drawing.Size(79, 23);
            this.btnRecAdd.TabIndex = 13;
            this.btnRecAdd.Text = "Kay�t Ekle";
            this.btnRecAdd.UseVisualStyleBackColor = true;
            this.btnRecAdd.Click += new System.EventHandler(this.btnRecAdd_Click);
            // 
            // btnRecRemove
            // 
            this.btnRecRemove.Location = new System.Drawing.Point(90, 187);
            this.btnRecRemove.Name = "btnRecRemove";
            this.btnRecRemove.Size = new System.Drawing.Size(79, 23);
            this.btnRecRemove.TabIndex = 14;
            this.btnRecRemove.Text = "Kay�t Sil";
            this.btnRecRemove.UseVisualStyleBackColor = true;
            this.btnRecRemove.Click += new System.EventHandler(this.btnRecRemove_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(175, 187);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(79, 23);
            this.btnExit.TabIndex = 15;
            this.btnExit.Text = "��k��";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // UygulamaSozlukForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(268, 223);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnRecRemove);
            this.Controls.Add(this.btnRecAdd);
            this.Controls.Add(this.btnRecList);
            this.Controls.Add(this.recValue);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.recKeyName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnDictRemove);
            this.Controls.Add(this.btnDictCreate);
            this.Controls.Add(this.btnDictExist);
            this.Controls.Add(this.btNodList);
            this.Controls.Add(this.dictName);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UygulamaSozlukForm";
            this.ShowInTaskbar = false;
            this.Text = "Kullan�c� Tan�ml� S�zl�k";
            this.Load += new System.EventHandler(this.UygulamaSozlukForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox dictName;
        private System.Windows.Forms.Button btNodList;
        private System.Windows.Forms.Button btnDictExist;
        private System.Windows.Forms.Button btnDictCreate;
        private System.Windows.Forms.Button btnDictRemove;
        private System.Windows.Forms.TextBox recKeyName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox recValue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnRecList;
        private System.Windows.Forms.Button btnRecAdd;
        private System.Windows.Forms.Button btnRecRemove;
        private System.Windows.Forms.Button btnExit;
    }
}