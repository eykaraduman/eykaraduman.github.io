using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.DatabaseServices;

namespace AbcSymbolTables
{
    public partial class UygulamaSozlukForm : Form
    {
        Database db = null;
        
        public UygulamaSozlukForm()
        {
            InitializeComponent();
        }

        private void UygulamaSozlukForm_Load(object sender, EventArgs e)
        {
            db =
                Autodesk.AutoCAD.ApplicationServices.Application.DocumentManager.MdiActiveDocument.Database;
        }

        private void btNodList_Click(object sender, EventArgs e)
        {
            NODRecList();
        }

        private void btnDictExist_Click(object sender, EventArgs e)
        {

        }

        private void btnDictCreate_Click(object sender, EventArgs e)
        {

        }

        private void btnDictRemove_Click(object sender, EventArgs e)
        {

        }

        private void btnRecList_Click(object sender, EventArgs e)
        {

        }

        private void btnRecAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnRecRemove_Click(object sender, EventArgs e)
        {

        }

        public void RemoveDictionary(string UygulamaAnahtar)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForWrite);

                if (NOD.Contains(UygulamaAnahtar))
                {
                    NOD.Remove(UygulamaAnahtar);
                    tr.Commit();
                }
                NOD.Dispose();
            }
        }

        public void CreateDictionary(string UygulamaAnahtar)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForRead);

                if (!NOD.Contains(UygulamaAnahtar))
                {
                    NOD.UpgradeOpen();
                    DBDictionary AppDict = new DBDictionary();
                    NOD.SetAt(UygulamaAnahtar, AppDict);
                    tr.AddNewlyCreatedDBObject(AppDict, true);
                    tr.Commit();
                }
                NOD.Dispose();
            }
        }

        public bool IsDictionaryExist(string UygulamaAnahtar)
        {
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForRead);
                if (NOD.Contains(UygulamaAnahtar))
                    return true;
            }
            return false;
        }

        public Xrecord CreateXRecord(string val)
        {
            Xrecord xrec = new Xrecord();
            xrec.Data = new ResultBuffer(new TypedValue((int)DxfCode.Text, val));
            return xrec;
        }

        public void AddOrUpdateDictionaryRecord(string UygulamaAnahtar, string key, string val)
        {
            if (!IsDictionaryExist(UygulamaAnahtar)) CreateDictionary(UygulamaAnahtar);

            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForWrite);
                DBDictionary AppDict = (DBDictionary)tr.GetObject(NOD.GetAt(UygulamaAnahtar), OpenMode.ForWrite);
                Xrecord kayit = CreateXRecord(val);
                AppDict.SetAt(key, kayit);
                tr.AddNewlyCreatedDBObject(kayit, true);
                tr.Commit();
                NOD.Dispose();
                AppDict.Dispose();
            }
        }

        public void NODRecList()
        {
            string nodList = "";
            using (Transaction tr = db.TransactionManager.StartTransaction())
            {
                // Veritaban� s�zl���n�n (NOD'un) okuma ama�l� a��lmas�
                DBDictionary NOD = (DBDictionary)tr.GetObject(db.NamedObjectsDictionaryId,
                    OpenMode.ForRead);
                // S�zl�k i�erisinde dola�mak i�in
                // veritaban� s�zl�k numaraland�r�c�s�n�n eldesi
                DbDictionaryEnumerator eNOD = NOD.GetEnumerator();
                while (eNOD.MoveNext())
                {
                    // S�zl�k kay�t anahtarlar�n�n AutoCAD 
                    // komut sat�r�na yazd�r�lmas�
                    nodList += "\n" + eNOD.Current.Key;
                }
                // Numaraland�r�c�n�n sonland�r�lmas�
                eNOD.Dispose();
                Autodesk.AutoCAD.ApplicationServices.Application.ShowAlertDialog(nodList);
            }
        }
    }
}